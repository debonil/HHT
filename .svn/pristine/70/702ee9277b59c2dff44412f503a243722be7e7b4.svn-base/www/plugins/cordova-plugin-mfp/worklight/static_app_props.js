// This is a generated file. Do not edit. See application-descriptor.xml.
// WLClient configuration variables.
console.log("Running static_app_props.js...");
var WL = WL ? WL : {};
WL.StaticAppProps = { APP_ID: 'in.gov.indianrail.hhtapp',
  APP_VERSION: '0.0.1',
  WORKLIGHT_PLATFORM_VERSION: '8.0.0.00-20170801-121015',
  WORKLIGHT_NATIVE_VERSION: '229521831',
  LANGUAGE_PREFERENCES: 'en',
  ENVIRONMENT: 'android',
  WORKLIGHT_ROOT_URL: '/apps/services/api/in.gov.indianrail.hhtapp/android/',
  APP_SERVICES_URL: '/apps/services/',
  APP_DISPLAY_NAME: 'HHT APP',
  LOGIN_DISPLAY_TYPE: 'embedded',
  mfpClientCustomInit: false,
  MESSAGES_DIR: 'plugins\\cordova-plugin-mfp\\worklight\\messages' };